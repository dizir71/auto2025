def scrape_autoscout24():
    # Simulierte Echtdaten
    return [{
        "fahrzeug": "BMW X5",
        "preis": 32400,
        "ez": "2020-01",
        "km": 68000,
        "antrieb": "Benzin",
        "bewertung": 9.1,
        "link": "https://www.autoscout24.de/beispiel1"
    }]
