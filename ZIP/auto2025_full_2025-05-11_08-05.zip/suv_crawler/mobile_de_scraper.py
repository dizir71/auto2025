def scrape_mobile_de():
    # Simulierte Echtdaten
    return [{
        "fahrzeug": "Audi Q7",
        "preis": 29800,
        "ez": "2019-09",
        "km": 92000,
        "antrieb": "Diesel",
        "bewertung": 8.4,
        "link": "https://www.mobile.de/beispiel1"
    }]
