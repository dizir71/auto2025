#!/bin/bash
# SUV Crawler – Sicherer Betrieb im Benutzerverzeichnis
# Letzte Aktualisierung: 2025-05-10

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOGFILE="$SCRIPT_DIR/suv_crawler.log"

echo "[$(date '+%F %T')] 🔄 Starte SUV-Daten-Crawler..." >> "$LOGFILE"

# Crawler-Skript starten
python3 "$SCRIPT_DIR/suv_crawler.py" >> "$LOGFILE" 2>&1

# Erfolgsmeldung schreiben
if [ $? -eq 0 ]; then
  echo "[$(date '+%F %T')] ✅ SUV-Crawler abgeschlossen." >> "$LOGFILE"
else
  echo "[$(date '+%F %T')] ❌ Fehler beim SUV-Crawler!" >> "$LOGFILE"
fi
