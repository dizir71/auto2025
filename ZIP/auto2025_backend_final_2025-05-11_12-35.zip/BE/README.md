# auto2025 Backend
Dieses Backend enthält die Crawler und Datenquellen für das Dashboard.