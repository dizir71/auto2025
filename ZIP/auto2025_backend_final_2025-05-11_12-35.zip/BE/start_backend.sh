#!/bin/bash
python3 crawler/suv_crawler.py
