#!/bin/bash
echo "[Test] SUV-Crawler-Testlauf..."
