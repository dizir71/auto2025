#!/bin/bash
echo "[Crawler] Dummy-Ausführung lokal..."
