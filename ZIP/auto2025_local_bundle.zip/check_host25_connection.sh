#!/bin/bash
echo "[Check] Verbindungstest zu host25..."
