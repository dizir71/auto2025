#!/bin/bash
cd AI/dashboard && python3 -m http.server 8080