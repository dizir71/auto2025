# auto2025 Live Dashboard
Einfach entpacken und `start_server.sh` ausführen.