Live-Version des SUV-Crawlers
Ort: ~/Desktop/GitHub/auto2025/suv_crawler
