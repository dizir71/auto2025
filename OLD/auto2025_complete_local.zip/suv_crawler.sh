#!/bin/bash
echo "[INFO] Starte lokalen SUV-Crawler..."
python3 suv_crawler.py
